package com.example.assetinventory.data

data class TaskInfo(
    val id: Long,
    val name: String,
    val assetCount: Int,
    val createdAt: Long
)
