package com.example.assetinventory.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.assetinventory.R
import com.example.assetinventory.data.LocalStore
import com.example.assetinventory.model.Asset
import com.example.assetinventory.model.AssetStatus

class AssetEditActivity : AppCompatActivity() {

    private lateinit var btnBackTaskList: Button
    private lateinit var btnBack: Button
    private lateinit var tvCode: TextView
    private lateinit var tvName: TextView
    private lateinit var tvStartDate: TextView
    private lateinit var etUser: EditText
    private lateinit var etDept: EditText
    private lateinit var etLocation: EditText
    private lateinit var btnCancel: Button
    private lateinit var btnConfirm: Button

    private var taskId: Long = -1L
    private var assetCode: String? = null
    private var currentAsset: Asset? = null
    private var returnToScanAfterSave: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_asset_edit)

        supportActionBar?.title = "修改资产信息"

        taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        assetCode = intent.getStringExtra(EXTRA_ASSET_CODE)
        returnToScanAfterSave = intent.getBooleanExtra(EXTRA_RETURN_TO_SCAN_AFTER_SAVE, false)

        if (taskId <= 0L || assetCode.isNullOrEmpty()) {
            Toast.makeText(this, "资产信息缺失", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        btnBackTaskList = findViewById(R.id.btnBackTaskList)
        btnBack = findViewById(R.id.btnBack)
        tvCode = findViewById(R.id.tvCode)
        tvName = findViewById(R.id.tvName)
        tvStartDate = findViewById(R.id.tvStartDate)
        etUser = findViewById(R.id.etUser)
        etDept = findViewById(R.id.etDept)
        etLocation = findViewById(R.id.etLocation)
        btnCancel = findViewById(R.id.btnCancel)
        btnConfirm = findViewById(R.id.btnConfirm)

        btnBackTaskList.setOnClickListener {
            val intent = Intent(this, TaskListActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
        }

        btnBack.setOnClickListener {
            finish()
        }

        loadAsset()

        btnCancel.setOnClickListener {
            finish()
        }

        btnConfirm.setOnClickListener {
            val user = etUser.text.toString().trim()
            val dept = etDept.text.toString().trim()
            val loc = etLocation.text.toString().trim()

            LocalStore.updateAssetDetails(
                this,
                taskId = taskId,
                code = assetCode!!,
                user = user,
                department = dept,
                location = loc,
                status = AssetStatus.MISMATCH
            )

            Toast.makeText(this, "修改已保存，状态已设为：不相符", Toast.LENGTH_SHORT).show()

            if (returnToScanAfterSave) {
                // 从扫码页因“全局有资产但不在当前筛选范围”进入修改页时，保存后直接回到扫码页继续盘点。
                finish()
                return@setOnClickListener
            }

            // 修改完成后返回资产列表页
            // 关键修复：不再把任务名称写成空字符串，而是继承原有的所有 extras
            val mainIntent = Intent(this, MainActivity::class.java)

            // 继承当前 Intent 携带的所有参数（包括任务名称），避免丢失
            this.intent.extras?.let { extras ->
                mainIntent.putExtras(extras)
            }

            // 确保任务 ID 正确（用最新的 taskId 覆盖）
            mainIntent.putExtra(MainActivity.EXTRA_TASK_ID, taskId)

            // 不再覆盖 EXTRA_TASK_NAME，保持原值
            mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(mainIntent)

            finish()
        }
    }

    private fun loadAsset() {
        val asset = LocalStore.findAssetByCode(this, taskId, assetCode!!)
        if (asset == null) {
            Toast.makeText(this, "未找到资产信息", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        currentAsset = asset
        tvCode.text = "资产编码：${asset.code}"

        // 拼接显示类别：名称 + 换行 + 类别（如果有）
        val categoryStr = if (asset.category.isNullOrEmpty()) "" else " \n资产类别：${asset.category}"
        tvName.text = "资产名称：${asset.name}$categoryStr"

        tvStartDate.text = "投用日期：${asset.startDate}"
        etUser.setText(asset.user.orEmpty())
        etDept.setText(asset.department.orEmpty())
        etLocation.setText(asset.location.orEmpty())
    }

    companion object {
        const val EXTRA_TASK_ID = "extra_task_id"
        const val EXTRA_ASSET_CODE = "extra_asset_code"
        private const val EXTRA_RETURN_TO_SCAN_AFTER_SAVE = "extra_return_to_scan_after_save"

        fun start(context: Context, taskId: Long, assetCode: String) {
            val intent = Intent(context, AssetEditActivity::class.java)
            intent.putExtra(EXTRA_TASK_ID, taskId)
            intent.putExtra(EXTRA_ASSET_CODE, assetCode)
            context.startActivity(intent)
        }

        fun startForScan(
            context: Context,
            taskId: Long,
            taskName: String,
            assetCode: String
        ) {
            val intent = Intent(context, AssetEditActivity::class.java)
            intent.putExtra(EXTRA_TASK_ID, taskId)
            intent.putExtra(EXTRA_ASSET_CODE, assetCode)
            intent.putExtra(MainActivity.EXTRA_TASK_NAME, taskName)
            intent.putExtra(EXTRA_RETURN_TO_SCAN_AFTER_SAVE, true)
            context.startActivity(intent)
        }
    }
}
