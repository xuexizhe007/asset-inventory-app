package com.example.assetinventory.ui

import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.assetinventory.R
import com.example.assetinventory.data.TaskFilterStore
import com.example.assetinventory.data.TaskInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TaskAdapter(
    private var items: List<TaskInfo>,
    private val departmentOptionsProvider: (TaskInfo) -> List<String>,
    private val filterProvider: (TaskInfo) -> TaskFilterStore.TaskFilter,
    private val filteredCountProvider: (TaskInfo) -> Pair<Int, Int>,
    private val statsProvider: (TaskInfo) -> List<DepartmentStats>,
    private val onItemClick: (TaskInfo) -> Unit,
    private val onDeleteClick: (TaskInfo) -> Unit,
    private val onExportClick: (TaskInfo) -> Unit,
    private val onApplyFilterClick: (TaskInfo, TaskFilterStore.TaskFilter) -> Unit,
    private val onClearFilterClick: (TaskInfo) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    data class DepartmentStats(
        val department: String,
        val unchecked: Int,
        val matched: Int,
        val mismatch: Int,
        val noLabel: Int,
        val total: Int,
        val isTotal: Boolean = false
    )

    fun update(newList: List<TaskInfo>) {
        items = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_task, parent, false)
        return TaskViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(items[position])
    }

    inner class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTaskName: TextView = itemView.findViewById(R.id.tvTaskName)
        private val tvTaskInfo: TextView = itemView.findViewById(R.id.tvTaskInfo)
        private val spTaskDepartment: Spinner = itemView.findViewById(R.id.spTaskDepartment)
        private val spTaskLocation1Mode: Spinner = itemView.findViewById(R.id.spTaskLocation1Mode)
        private val etTaskLocation1: EditText = itemView.findViewById(R.id.etTaskLocation1)
        private val spTaskLocation2Mode: Spinner = itemView.findViewById(R.id.spTaskLocation2Mode)
        private val etTaskLocation2: EditText = itemView.findViewById(R.id.etTaskLocation2)
        private val btnOpenTask: Button = itemView.findViewById(R.id.btnOpenTask)
        private val btnApplyTaskFilter: Button = itemView.findViewById(R.id.btnApplyTaskFilter)
        private val btnClearTaskFilter: Button = itemView.findViewById(R.id.btnClearTaskFilter)
        private val btnDeleteTask: Button = itemView.findViewById(R.id.btnDeleteTask)
        private val btnExportTask: Button = itemView.findViewById(R.id.btnExportTask)
        private val tableTaskStats: TableLayout = itemView.findViewById(R.id.tableTaskStats)

        private val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

        fun bind(task: TaskInfo) {
            val context = itemView.context
            val filter = filterProvider(task)
            val departmentOptions = departmentOptionsProvider(task)
            val locationModes = TaskFilterStore.LocationMode.values().map { it.displayName }
            val countPair = filteredCountProvider(task)
            val filteredCount = countPair.first
            val totalCount = countPair.second

            tvTaskName.text = task.name
            val timeText = sdf.format(Date(task.createdAt))
            tvTaskInfo.text = "导入时间：$timeText    筛选后 $filteredCount / 共 $totalCount 条资产"

            spTaskDepartment.adapter = ArrayAdapter(
                context,
                R.layout.item_spinner_small,
                departmentOptions
            ).also { it.setDropDownViewResource(R.layout.item_spinner_dropdown_small) }
            val departmentIndex = departmentOptions.indexOf(filter.department).takeIf { it >= 0 } ?: 0
            spTaskDepartment.setSelection(departmentIndex)

            spTaskLocation1Mode.adapter = ArrayAdapter(
                context,
                R.layout.item_spinner_small,
                locationModes
            ).also { it.setDropDownViewResource(R.layout.item_spinner_dropdown_small) }
            spTaskLocation1Mode.setSelection(modeIndex(filter.location1Mode))

            spTaskLocation2Mode.adapter = ArrayAdapter(
                context,
                R.layout.item_spinner_small,
                locationModes
            ).also { it.setDropDownViewResource(R.layout.item_spinner_dropdown_small) }
            spTaskLocation2Mode.setSelection(modeIndex(filter.location2Mode))

            etTaskLocation1.inputType = InputType.TYPE_CLASS_TEXT
            etTaskLocation2.inputType = InputType.TYPE_CLASS_TEXT
            etTaskLocation1.setSingleLine(true)
            etTaskLocation2.setSingleLine(true)
            etTaskLocation1.setText(filter.location1Text)
            etTaskLocation2.setText(filter.location2Text)

            buildStatsTable(statsProvider(task))

            itemView.setOnClickListener { onItemClick(task) }
            btnOpenTask.setOnClickListener { onItemClick(task) }
            btnApplyTaskFilter.setOnClickListener {
                val selectedDepartment = spTaskDepartment.selectedItem?.toString()
                    ?: TaskFilterStore.ALL_DEPARTMENTS
                val newFilter = TaskFilterStore.TaskFilter(
                    department = selectedDepartment,
                    location1Text = etTaskLocation1.text.toString().trim(),
                    location1Mode = selectedLocationMode(spTaskLocation1Mode),
                    location2Text = etTaskLocation2.text.toString().trim(),
                    location2Mode = selectedLocationMode(spTaskLocation2Mode)
                )
                onApplyFilterClick(task, newFilter)
            }
            btnClearTaskFilter.setOnClickListener { onClearFilterClick(task) }
            btnDeleteTask.setOnClickListener { onDeleteClick(task) }
            btnExportTask.setOnClickListener { onExportClick(task) }
        }

        private fun buildStatsTable(rows: List<DepartmentStats>) {
            tableTaskStats.removeAllViews()
            addStatsRow(
                listOf("使用部门", "未盘点", "相符", "不相符", "补打标签", "合计数量"),
                isHeader = true,
                isTotal = false
            )
            if (rows.isEmpty()) {
                addStatsRow(listOf("总计", "0", "0", "0", "0", "0"), isHeader = false, isTotal = true)
                return
            }
            rows.forEach { row ->
                addStatsRow(
                    listOf(
                        row.department,
                        row.unchecked.toString(),
                        row.matched.toString(),
                        row.mismatch.toString(),
                        row.noLabel.toString(),
                        row.total.toString()
                    ),
                    isHeader = false,
                    isTotal = row.isTotal
                )
            }
        }

        private fun addStatsRow(values: List<String>, isHeader: Boolean, isTotal: Boolean) {
            val row = TableRow(itemView.context)
            row.layoutParams = TableLayout.LayoutParams(
                TableLayout.LayoutParams.WRAP_CONTENT,
                TableLayout.LayoutParams.WRAP_CONTENT
            )
            values.forEachIndexed { index, value ->
                row.addView(createStatsCell(value, index, isHeader, isTotal))
            }
            tableTaskStats.addView(row)
        }

        private fun createStatsCell(text: String, index: Int, isHeader: Boolean, isTotal: Boolean): TextView {
            val cellMinWidth = dp(if (index == 0) 112 else if (index == 4 || index == 5) 78 else 64)
            return TextView(itemView.context).apply {
                layoutParams = TableRow.LayoutParams(
                    TableRow.LayoutParams.WRAP_CONTENT,
                    dp(34)
                ).also {
                    it.setMargins(0, 0, dp(3), dp(3))
                }
                this.text = text
                textSize = 12f
                minWidth = cellMinWidth
                gravity = if (index == 0) Gravity.CENTER_VERTICAL else Gravity.CENTER
                setPadding(dp(6), 0, dp(6), 0)
                setSingleLine(true)
                setBackgroundResource(if (isHeader || isTotal) R.drawable.bg_filter_field else R.drawable.bg_filter_input)
                if (isHeader || isTotal) {
                    setTypeface(typeface, Typeface.BOLD)
                }
            }
        }

        private fun dp(value: Int): Int {
            return (value * itemView.resources.displayMetrics.density + 0.5f).toInt()
        }

        private fun selectedLocationMode(spinner: Spinner): TaskFilterStore.LocationMode {
            return if (spinner.selectedItemPosition == 1) {
                TaskFilterStore.LocationMode.NOT_CONTAINS
            } else {
                TaskFilterStore.LocationMode.CONTAINS
            }
        }

        private fun modeIndex(mode: TaskFilterStore.LocationMode): Int {
            return if (mode == TaskFilterStore.LocationMode.NOT_CONTAINS) 1 else 0
        }
    }
}
