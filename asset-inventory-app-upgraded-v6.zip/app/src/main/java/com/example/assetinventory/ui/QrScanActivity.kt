package com.example.assetinventory.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.assetinventory.R
import com.example.assetinventory.data.LocalStore
import com.example.assetinventory.data.TaskFilterStore
import com.example.assetinventory.model.Asset
import com.journeyapps.barcodescanner.BarcodeCallback
import com.journeyapps.barcodescanner.BarcodeResult
import com.journeyapps.barcodescanner.DecoratedBarcodeView

class QrScanActivity : AppCompatActivity() {

    private lateinit var btnBackTaskList: Button
    private lateinit var btnBack: Button
    private lateinit var barcodeView: DecoratedBarcodeView
    private lateinit var btnFlash: Button
    private lateinit var seekBarZoom: SeekBar
    private lateinit var tvTitle: TextView
    private lateinit var tvSubtitle: TextView

    private var handled = false
    private var taskId: Long = -1L
    private var taskName: String = ""
    private var taskFilter: TaskFilterStore.TaskFilter = TaskFilterStore.TaskFilter()

    // 闪光灯状态
    private var isFlashOn = false
    private lateinit var scaleGestureDetector: ScaleGestureDetector
    private var currentZoomProgress = 0

    private val callback = object : BarcodeCallback {
        override fun barcodeResult(result: BarcodeResult?) {
            if (result == null || handled) return
            handled = true
            val code = result.text?.trim().orEmpty()
            if (code.isEmpty()) {
                handled = false
                return
            }

            val asset = LocalStore.findAssetByCode(this@QrScanActivity, taskId, code)
            if (asset == null) {
                Toast.makeText(this@QrScanActivity, "未找到资产编码：$code", Toast.LENGTH_LONG).show()
                // 延迟一下重新允许扫码，否则 Toast 可能重叠
                barcodeView.postDelayed({ handled = false }, 2000)
            } else if (!isAssetInCurrentInventoryScope(asset)) {
                showOutOfScopeDialog(asset)
            } else {
                val intent = Intent(this@QrScanActivity, AssetDetailActivity::class.java)
                intent.putExtra(AssetDetailActivity.EXTRA_TASK_ID, taskId)
                intent.putExtra(AssetDetailActivity.EXTRA_ASSET_CODE, asset.code)
                startActivity(intent)
                finish()
            }
        }

        override fun possibleResultPoints(resultPoints: MutableList<com.google.zxing.ResultPoint>?) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qr_scan)

        taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        taskName = intent.getStringExtra(EXTRA_TASK_NAME) ?: ""
        if (taskId <= 0L) {
            Toast.makeText(this, "任务信息缺失", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        taskFilter = TaskFilterStore.getFilter(this, taskId)

        // 初始化视图
        btnBackTaskList = findViewById(R.id.btnBackTaskList)
        btnBack = findViewById(R.id.btnBack)
        barcodeView = findViewById(R.id.barcodeScanner)
        btnFlash = findViewById(R.id.btnFlash)
        seekBarZoom = findViewById(R.id.seekBarZoom)
        tvTitle = findViewById(R.id.tvTitle)
        tvSubtitle = findViewById(R.id.tvSubtitle)

        // 设置标题
        val filterSuffix = buildFilterSummary()
        tvTitle.text = "扫码 - $taskName"
        tvSubtitle.text = filterSuffix.ifBlank { "请将二维码对准扫描框" }
        // 如果使用了系统 ActionBar，也可以设置一下
        supportActionBar?.hide() // 使用了自定义 Toolbar，隐藏系统 ActionBar

        // 按钮事件
        btnBackTaskList.setOnClickListener {
            val intent = Intent(this, TaskListActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
            finish()
        }

        btnBack.setOnClickListener {
            finish()
        }

        // --- 功能 1: 闪光灯控制 ---
        btnFlash.setOnClickListener {
            if (isFlashOn) {
                barcodeView.setTorchOff()
                isFlashOn = false
                btnFlash.text = "开启闪光灯"
            } else {
                barcodeView.setTorchOn()
                isFlashOn = true
                btnFlash.text = "关闭闪光灯"
            }
        }

        // --- 功能 2: 镜头缩放控制 ---
        // SeekBar 范围 0-100，映射到相机的 Zoom 级别
        seekBarZoom.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    setZoomProgress(progress, updateSeekBar = false)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        setupPinchZoom()

        barcodeView.decodeContinuous(callback)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupPinchZoom() {
        scaleGestureDetector = ScaleGestureDetector(
            this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    val delta = ((detector.scaleFactor - 1f) * PINCH_ZOOM_SENSITIVITY).toInt()
                    if (delta != 0) {
                        setZoomProgress(currentZoomProgress + delta, updateSeekBar = true)
                    }
                    return true
                }
            }
        )

        barcodeView.setOnTouchListener { _, event: MotionEvent ->
            scaleGestureDetector.onTouchEvent(event)
            true
        }
    }

    private fun setZoomProgress(progress: Int, updateSeekBar: Boolean) {
        val clampedProgress = progress.coerceIn(0, 100)
        if (currentZoomProgress == clampedProgress && seekBarZoom.progress == clampedProgress) return

        currentZoomProgress = clampedProgress
        if (updateSeekBar && seekBarZoom.progress != clampedProgress) {
            seekBarZoom.progress = clampedProgress
        }
        updateCameraZoom(clampedProgress)
    }

    /**
     * 更新相机焦距
     * 使用 ZXing 库的 changeCameraParameters 接口
     */
    private fun updateCameraZoom(progress: Int) {
        barcodeView.barcodeView.changeCameraParameters { params ->
            // Android Camera API (deprecated but used by ZXing Embedded)
            if (params.isZoomSupported) {
                val maxZoom = params.maxZoom
                // 计算目标 zoom 值
                val targetZoom = (maxZoom * progress) / 100

                if (params.zoom != targetZoom) {
                    params.zoom = targetZoom
                }
            }
            params
        }
    }

    private fun isAssetInCurrentInventoryScope(asset: Asset): Boolean {
        return TaskFilterStore.matches(asset, taskFilter)
    }

    private fun showOutOfScopeDialog(asset: Asset) {
        barcodeView.pause()

        val assetScope = "资产部门：${asset.department.orEmpty()}\n资产地点：${asset.location.orEmpty()}"
        val currentScope = buildFilterSummary().ifBlank { "全部部门 / 全部地点" }

        AlertDialog.Builder(this)
            .setTitle("资产不在当前筛选范围")
            .setMessage(
                "资产编码：${asset.code}\n" +
                        "资产名称：${asset.name}\n\n" +
                        "当前筛选：$currentScope\n" +
                        "$assetScope\n\n" +
                        "该资产存在于本任务全部资产中，但不在当前筛选范围。确认后将进入资产修改页面。"
            )
            .setNegativeButton("取消") { _, _ -> resumeScanning() }
            .setPositiveButton("确认修改") { _, _ ->
                AssetEditActivity.startForScan(
                    context = this,
                    taskId = taskId,
                    taskName = taskName,
                    assetCode = asset.code
                )
            }
            .setOnCancelListener { resumeScanning() }
            .show()
    }

    private fun buildFilterSummary(): String {
        val summary = TaskFilterStore.buildSummary(taskFilter)
        return if (summary == "筛选：全部资产") "" else summary
    }

    private fun resumeScanning() {
        barcodeView.resume()
        barcodeView.postDelayed({ handled = false }, 500)
    }

    override fun onResume() {
        super.onResume()
        handled = false
        barcodeView.resume()

        // 恢复时重置 UI 状态
        if (isFlashOn) {
            barcodeView.setTorchOn()
        }
    }

    override fun onPause() {
        super.onPause()
        barcodeView.pause()
    }

    // 处理按键事件，如音量键控制缩放（可选增强体验）
    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        return barcodeView.onKeyDown(keyCode, event) || super.onKeyDown(keyCode, event)
    }

    companion object {
        const val EXTRA_TASK_ID = "extra_task_id"
        const val EXTRA_TASK_NAME = "extra_task_name"
        private const val PINCH_ZOOM_SENSITIVITY = 120f
    }
}
