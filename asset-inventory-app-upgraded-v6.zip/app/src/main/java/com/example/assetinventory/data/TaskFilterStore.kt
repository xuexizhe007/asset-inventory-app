package com.example.assetinventory.data

import android.content.Context
import com.example.assetinventory.model.Asset

object TaskFilterStore {

    data class TaskFilter(
        val department: String = ALL_DEPARTMENTS,
        val location1Text: String = "",
        val location1Mode: LocationMode = LocationMode.CONTAINS,
        val location2Text: String = "",
        val location2Mode: LocationMode = LocationMode.CONTAINS
    ) {
        val location1Keywords: List<String>
            get() = parseLocationKeywords(location1Text)

        val location2Keywords: List<String>
            get() = parseLocationKeywords(location2Text)
    }

    enum class LocationMode(val displayName: String) {
        CONTAINS("包含"),
        NOT_CONTAINS("不包含")
    }

    fun getFilter(context: Context, taskId: Long): TaskFilter {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val department = prefs.getString(key(taskId, KEY_DEPARTMENT), ALL_DEPARTMENTS)
            ?.takeIf { it.isNotBlank() }
            ?: ALL_DEPARTMENTS

        // 兼容旧版本保存的单地点筛选：旧 location_text 自动作为地点1读取。
        val legacyLocationText = prefs.getString(key(taskId, LEGACY_KEY_LOCATION_TEXT), "").orEmpty()
        val legacyModeName = prefs.getString(key(taskId, LEGACY_KEY_LOCATION_MODE), LocationMode.CONTAINS.name)
        val legacyMode = parseLocationMode(legacyModeName)

        val location1Text = prefs.getString(key(taskId, KEY_LOCATION1_TEXT), null)
            ?: legacyLocationText
        val location1Mode = parseLocationMode(
            prefs.getString(key(taskId, KEY_LOCATION1_MODE), null) ?: legacyMode.name
        )
        val location2Text = prefs.getString(key(taskId, KEY_LOCATION2_TEXT), "").orEmpty()
        val location2Mode = parseLocationMode(
            prefs.getString(key(taskId, KEY_LOCATION2_MODE), LocationMode.CONTAINS.name)
        )

        return TaskFilter(
            department = department,
            location1Text = location1Text,
            location1Mode = location1Mode,
            location2Text = location2Text,
            location2Mode = location2Mode
        )
    }

    fun saveFilter(context: Context, taskId: Long, filter: TaskFilter) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(key(taskId, KEY_DEPARTMENT), filter.department.ifBlank { ALL_DEPARTMENTS })
            .putString(key(taskId, KEY_LOCATION1_TEXT), filter.location1Text)
            .putString(key(taskId, KEY_LOCATION1_MODE), filter.location1Mode.name)
            .putString(key(taskId, KEY_LOCATION2_TEXT), filter.location2Text)
            .putString(key(taskId, KEY_LOCATION2_MODE), filter.location2Mode.name)
            .remove(key(taskId, LEGACY_KEY_LOCATION_TEXT))
            .remove(key(taskId, LEGACY_KEY_LOCATION_MODE))
            .apply()
    }

    fun clearFilter(context: Context, taskId: Long) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(key(taskId, KEY_DEPARTMENT))
            .remove(key(taskId, KEY_LOCATION1_TEXT))
            .remove(key(taskId, KEY_LOCATION1_MODE))
            .remove(key(taskId, KEY_LOCATION2_TEXT))
            .remove(key(taskId, KEY_LOCATION2_MODE))
            .remove(key(taskId, LEGACY_KEY_LOCATION_TEXT))
            .remove(key(taskId, LEGACY_KEY_LOCATION_MODE))
            .apply()
    }

    fun applyFilter(assets: List<Asset>, filter: TaskFilter): List<Asset> {
        return assets.filter { matches(it, filter) }
    }

    fun matches(asset: Asset, filter: TaskFilter): Boolean {
        val matchDepartment = filter.department == ALL_DEPARTMENTS ||
                asset.department?.trim() == filter.department

        return matchDepartment &&
                matchesLocationRule(asset.location.orEmpty(), filter.location1Keywords, filter.location1Mode) &&
                matchesLocationRule(asset.location.orEmpty(), filter.location2Keywords, filter.location2Mode)
    }

    fun buildSummary(filter: TaskFilter): String {
        val parts = mutableListOf<String>()
        if (filter.department != ALL_DEPARTMENTS) {
            parts.add("使用部门等于：${filter.department}")
        }
        val location1Keywords = filter.location1Keywords
        if (location1Keywords.isNotEmpty()) {
            parts.add("地点1${filter.location1Mode.displayName}：${location1Keywords.joinToString("、")}")
        }
        val location2Keywords = filter.location2Keywords
        if (location2Keywords.isNotEmpty()) {
            parts.add("地点2${filter.location2Mode.displayName}：${location2Keywords.joinToString("、")}")
        }
        return if (parts.isEmpty()) "筛选：全部资产" else "筛选：${parts.joinToString("；")}"
    }

    private fun matchesLocationRule(location: String, keywords: List<String>, mode: LocationMode): Boolean {
        if (keywords.isEmpty()) return true
        val containsAny = keywords.any { keyword ->
            location.contains(keyword, ignoreCase = true)
        }
        return when (mode) {
            LocationMode.CONTAINS -> containsAny
            LocationMode.NOT_CONTAINS -> !containsAny
        }
    }

    private fun parseLocationMode(value: String?): LocationMode {
        return try {
            LocationMode.valueOf(value ?: LocationMode.CONTAINS.name)
        } catch (_: Exception) {
            LocationMode.CONTAINS
        }
    }

    private fun parseLocationKeywords(text: String): List<String> {
        val keyword = text.trim()
        return if (keyword.isEmpty()) emptyList() else listOf(keyword)
    }

    private fun key(taskId: Long, key: String): String = "task_${taskId}_$key"

    const val ALL_DEPARTMENTS = "全部部门"

    private const val PREF_NAME = "task_scope_filters"
    private const val KEY_DEPARTMENT = "department"
    private const val KEY_LOCATION1_TEXT = "location1_text"
    private const val KEY_LOCATION1_MODE = "location1_mode"
    private const val KEY_LOCATION2_TEXT = "location2_text"
    private const val KEY_LOCATION2_MODE = "location2_mode"

    private const val LEGACY_KEY_LOCATION_TEXT = "location_text"
    private const val LEGACY_KEY_LOCATION_MODE = "location_mode"
}
