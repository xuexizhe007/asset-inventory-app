package com.example.assetinventory.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.assetinventory.R
import com.example.assetinventory.data.LocalStore
import com.example.assetinventory.data.TaskFilterStore
import com.example.assetinventory.data.TaskInfo
import com.example.assetinventory.model.Asset
import com.example.assetinventory.model.AssetStatus
import com.example.assetinventory.util.ExcelExporter
import com.example.assetinventory.util.ExcelImporter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TaskListActivity : AppCompatActivity() {

    private lateinit var btnBackTaskList: Button
    private lateinit var btnBack: Button
    private lateinit var btnImportTask: Button
    private lateinit var rvTasks: RecyclerView
    private lateinit var adapter: TaskAdapter

    private var pendingExportFileName: String? = null
    private var pendingExportBytes: ByteArray? = null

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            importExcel(uri)
        }
    }

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult

        val bytes = pendingExportBytes
        if (bytes == null) {
            Toast.makeText(this, "导出失败：没有可写入的数据", Toast.LENGTH_LONG).show()
            return@registerForActivityResult
        }

        try {
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
                out.flush()
            }
            Toast.makeText(this, "导出成功", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            e.printStackTrace()
            AlertDialog.Builder(this)
                .setTitle("导出失败")
                .setMessage(e.message ?: "未知错误")
                .setPositiveButton("确定", null)
                .show()
        } finally {
            pendingExportBytes = null
            pendingExportFileName = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_list)

        btnBackTaskList = findViewById(R.id.btnBackTaskList)
        btnBack = findViewById(R.id.btnBack)
        btnImportTask = findViewById(R.id.btnImportTask)
        rvTasks = findViewById(R.id.rvTasks)

        supportActionBar?.title = getString(R.string.task_list_title)

        btnBackTaskList.setOnClickListener { finish() }
        btnBack.setOnClickListener { finish() }
        btnImportTask.setOnClickListener { openExcelPicker() }

        adapter = TaskAdapter(
            items = emptyList(),
            departmentOptionsProvider = { task -> buildDepartmentOptions(task) },
            filterProvider = { task -> TaskFilterStore.getFilter(this, task.id) },
            filteredCountProvider = { task -> buildFilteredCount(task) },
            statsProvider = { task -> buildDepartmentStats(task) },
            onItemClick = { openTask(it) },
            onDeleteClick = { confirmDelete(it) },
            onExportClick = { exportTask(it) },
            onApplyFilterClick = { task, filter -> saveTaskFilter(task, filter) },
            onClearFilterClick = { clearTaskFilter(it) }
        )

        rvTasks.layoutManager = LinearLayoutManager(this)
        rvTasks.adapter = adapter

        loadTasks()
    }

    override fun onResume() {
        super.onResume()
        if (::adapter.isInitialized) {
            loadTasks()
        }
    }

    private fun openExcelPicker() {
        importLauncher.launch(
            arrayOf(
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
        )
    }

    private fun importExcel(uri: Uri) {
        try {
            val result = ExcelImporter.import(this, uri)
            if (result.assets.isEmpty()) {
                Toast.makeText(this, "表格没有有效资产数据", Toast.LENGTH_LONG).show()
                return
            }
            LocalStore.insertTaskWithAssets(this, result.taskName, result.assets)
            Toast.makeText(this, "导入成功，生成任务：${result.taskName}", Toast.LENGTH_LONG).show()
            loadTasks()
        } catch (e: Exception) {
            e.printStackTrace()
            AlertDialog.Builder(this)
                .setTitle("导入失败")
                .setMessage(e.message ?: "未知错误")
                .setPositiveButton("确定", null)
                .show()
        }
    }

    private fun loadTasks() {
        val tasks = LocalStore.getTasks(this)
        adapter.update(tasks)
    }

    private fun openTask(task: TaskInfo) {
        if (task.assetCount <= 0) {
            Toast.makeText(this, "该任务没有资产记录", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra(MainActivity.EXTRA_TASK_ID, task.id)
        intent.putExtra(MainActivity.EXTRA_TASK_NAME, task.name)
        startActivity(intent)
    }

    private fun confirmDelete(task: TaskInfo) {
        AlertDialog.Builder(this)
            .setTitle("删除任务")
            .setMessage("确认删除任务“${task.name}”及其所有资产信息吗？此操作不可恢复。")
            .setNegativeButton("取消", null)
            .setPositiveButton("删除") { _, _ ->
                try {
                    LocalStore.deleteTaskCascade(this, task.id)
                    TaskFilterStore.clearFilter(this, task.id)
                    Toast.makeText(this, "已删除：${task.name}", Toast.LENGTH_LONG).show()
                    loadTasks()
                } catch (e: Exception) {
                    e.printStackTrace()
                    AlertDialog.Builder(this)
                        .setTitle("删除失败")
                        .setMessage(e.message ?: "未知错误")
                        .setPositiveButton("确定", null)
                        .show()
                }
            }
            .show()
    }

    private fun buildDepartmentOptions(task: TaskInfo): List<String> {
        val assets = LocalStore.getAssetsByTask(this, task.id)
        val departments = assets
            .mapNotNull { it.department?.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .sortedWith(compareBy { it.lowercase(Locale.getDefault()) })
        return listOf(TaskFilterStore.ALL_DEPARTMENTS) + departments
    }

    private fun saveTaskFilter(task: TaskInfo, filter: TaskFilterStore.TaskFilter) {
        TaskFilterStore.saveFilter(this, task.id, filter)
        Toast.makeText(this, "已保存“${task.name}”的筛选条件", Toast.LENGTH_SHORT).show()
        loadTasks()
    }

    private fun clearTaskFilter(task: TaskInfo) {
        TaskFilterStore.clearFilter(this, task.id)
        Toast.makeText(this, "已清空“${task.name}”的筛选条件", Toast.LENGTH_SHORT).show()
        loadTasks()
    }

    private fun buildFilteredCount(task: TaskInfo): Pair<Int, Int> {
        val assets = LocalStore.getAssetsByTask(this, task.id)
        val filteredCount = TaskFilterStore.applyFilter(assets, TaskFilterStore.getFilter(this, task.id)).size
        return filteredCount to assets.size
    }

    private fun buildDepartmentStats(task: TaskInfo): List<TaskAdapter.DepartmentStats> {
        val assets = LocalStore.getAssetsByTask(this, task.id)
        val filteredAssets = TaskFilterStore.applyFilter(assets, TaskFilterStore.getFilter(this, task.id))
        return buildDepartmentStatsRows(filteredAssets)
    }

    private fun buildDepartmentStatsRows(assets: List<Asset>): List<TaskAdapter.DepartmentStats> {
        val rows = assets
            .groupBy { it.department?.trim()?.takeIf { dept -> dept.isNotEmpty() } ?: "未填写" }
            .toSortedMap(compareBy<String> { it.lowercase(Locale.getDefault()) })
            .map { (department, deptAssets) ->
                TaskAdapter.DepartmentStats(
                    department = department,
                    unchecked = deptAssets.count { it.status == AssetStatus.UNCHECKED },
                    matched = deptAssets.count { it.status == AssetStatus.MATCHED },
                    mismatch = deptAssets.count { it.status == AssetStatus.MISMATCH },
                    noLabel = deptAssets.count { it.status == AssetStatus.LABEL_REPRINT },
                    total = deptAssets.size
                )
            }
            .toMutableList()

        rows.add(
            TaskAdapter.DepartmentStats(
                department = "总计",
                unchecked = assets.count { it.status == AssetStatus.UNCHECKED },
                matched = assets.count { it.status == AssetStatus.MATCHED },
                mismatch = assets.count { it.status == AssetStatus.MISMATCH },
                noLabel = assets.count { it.status == AssetStatus.LABEL_REPRINT },
                total = assets.size,
                isTotal = true
            )
        )
        return rows
    }

    private fun exportTask(task: TaskInfo) {
        if (task.assetCount <= 0) {
            Toast.makeText(this, "该任务没有资产记录", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val assets = LocalStore.getAssetsByTask(this, task.id)
            if (assets.isEmpty()) {
                Toast.makeText(this, "该任务没有资产记录", Toast.LENGTH_SHORT).show()
                return
            }

            val filter = TaskFilterStore.getFilter(this, task.id)
            val filteredAssets = TaskFilterStore.applyFilter(assets, filter)
            if (filteredAssets.isEmpty()) {
                Toast.makeText(this, "当前筛选条件下没有可导出的资产", Toast.LENGTH_SHORT).show()
                return
            }

            val bytes = ExcelExporter.exportFromTemplate(this, filteredAssets)

            val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
            val ts = sdf.format(Date())
            val safeName = task.name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            val filename = "${safeName}_筛选导出_${ts}.xlsx"

            pendingExportFileName = filename
            pendingExportBytes = bytes
            exportLauncher.launch(filename)
        } catch (e: Exception) {
            e.printStackTrace()
            AlertDialog.Builder(this)
                .setTitle("导出失败")
                .setMessage(e.message ?: "未知错误")
                .setPositiveButton("确定", null)
                .show()
        }
    }
}
